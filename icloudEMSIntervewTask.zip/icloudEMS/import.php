<?php include('config.php');
session_start();
if(!$_SESSION['data']){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Data | GPC Task</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Option 2: Separate Popper and Bootstrap JS -->
  
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</head>
<body class="bg-dark">
    <div class="container-fluid ms-auto">
        <div class="row pt-5">
            <div class="col-md-4 ">
                <form action="import_file.php" method="post" name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">

                    <div class="card">
                        <div class="card-header bg-primary">
                            <h3 class="card-title">Upload Data</h3>
                        </div>
                        
                        <div class="card-body">
                 
                            <div class="mb-3 row">
                                <label for="" class="col-sm-3 col-form-label">Upload</label>
                                <div class="col-sm-9">
                                <input type="file" class="form-control" name="file" id="file" accept=".xls,.xlsx,.csv">
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" id="submit" name="import" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-md-8">
               

                    <div class="card">
                        <div class="card-header bg-primary">
                            <h3 class="card-title">List Of Uploaded  Excel</h3>
                        </div>
                        
                        <div class="card-body">
                            <form action="" method="post">
                                <div class="mb-3 row">
                                    <label for="" class="col-sm-2 col-form-label">Select Chunks</label>
                                    <div class="col-sm-4">
                                    <select name="chunkfile" id="" class="form-control">
                                    <?php
                            $sqlDist = mysqli_query($conn,"SELECT DISTINCT(`filename`) FROM `cas_data`");
                            while ($rows = mysqli_fetch_assoc($sqlDist)) {
                            ?>
                                <option value="<?php echo $rows['filename'] ?>"><?php echo $rows['filename'] ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                    </div>
                                    <div class="col-sm-3">
                                        <input type="submit" name="viewChunk" value="View Chunks" class="btn btn-primary" >
                                    </div>
                                    <div class="col-sm-3">
                                        <input type="submit" name="ViewAll" value="View All Data" class="btn btn-primary" >
                                    </div>
                                </div>
                            </form>
                            
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Sr_No</th>
                                <th scope="col">Cas_Number</th>
                                <th scope="col">Cas_Name</th>
                                <th scope="col">Ec_Number</th>
                                <th scope="col">Decription</th>
                                <th scope="col">Structure</th>
                                <th scope="col">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php
                                if(isset($_POST['ViewAll'])) {
                                    $sql = mysqli_query($conn,"SELECT * FROM `cas_data`");
                                    $i = 1;
                                    while($row = mysqli_fetch_assoc($sql)){ ?>
                                        <tr>
                                            <th scope="row"><?php echo $i;?> </th>
                                            <td><?php echo $row['cas_number']; ?></td>
                                            <td><?php echo $row['cas_name']; ?></td>
                                            <td><?php echo $row['ec_number']; ?></td>
                                            <td><?php echo $row['description']; ?></td>
                                            <td><?php echo $row['structure']; ?></td>
                                            <td><?php echo $row['status']; ?></td>
                                        </tr>
                                        <?php $i++; }
                                }else if(isset($_POST['viewChunk'])){
                                    $sql = mysqli_query($conn,"SELECT * FROM `cas_data` WHERE `filename`='".$_POST['chunkfile']."'");
                                    $i = 1;
                                    while($row = mysqli_fetch_assoc($sql)){ ?>
                                        <tr>
                                            <th scope="row"><?php echo $i;?> </th>
                                            <td><?php echo $row['cas_number']; ?></td>
                                            <td><?php echo $row['cas_name']; ?></td>
                                            <td><?php echo $row['ec_number']; ?></td>
                                            <td><?php echo $row['description']; ?></td>
                                            <td><?php echo $row['structure']; ?></td>
                                            <td><?php echo $row['status']; ?></td>
                                        </tr>
                                        <?php $i++; }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</body>
</html>
