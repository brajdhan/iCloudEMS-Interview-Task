<?php
include('config.php');
require_once('vendor/excel-reader/excel_reader2.php');
require_once('vendor/SpreadsheetReader.php');

if (isset($_POST["import"]))
{
  $allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','text/x-comma-separated-values', 'text/comma-separated-values', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];

  if(in_array($_FILES["file"]["type"],$allowedFileType)){

        $targetPath = 'uploads/'.$_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);

        $Reader = new SpreadsheetReader($targetPath);
        $sheetCount = count($Reader->sheets());
       // exit();
        for($i=0;$i<$sheetCount;$i++)
        {            
            $Reader->ChangeSheet($i);
            foreach ($Reader as $Row)
            {

                $col1 = "";
                if(isset($Row[0])) {
                    $col1 = mysqli_real_escape_string($conn,$Row[0]);
                }

                $col2 = "";
                if(isset($Row[1])) {
                    $col2 = mysqli_real_escape_string($conn,$Row[1]);
                }

                $col3 = "";
                if(isset($Row[2])) {
                    $col3 = mysqli_real_escape_string($conn,$Row[2]);
                }

                $col4 = "";
                if(isset($Row[3])) {
                    $col4 = mysqli_real_escape_string($conn,$Row[3]);
                }

                $col5 = "";
                if(isset($Row[4])) {
                    $col5 = mysqli_real_escape_string($conn,$Row[4]);
                }
                
                $col6 = "";
                if(isset($Row[5])) {
                    $col6 = mysqli_real_escape_string($conn,$Row[5]);
                }

                $col7 = "";
                if(isset($Row[6])) {
                    $col7 = mysqli_real_escape_string($conn,$Row[6]);
                }

                $col8 = "";
                if(isset($Row[7])) {
                    $col8 = mysqli_real_escape_string($conn,$Row[7]);
                }

                $col9 = "";
                if(isset($Row[8])) {
                    $col9 = mysqli_real_escape_string($conn,$Row[8]);
                }

                $col10 = "";
                if(isset($Row[9])) {
                    $col10 = mysqli_real_escape_string($conn,$Row[9]);
                }

                $col11 = "";
                if(isset($Row[10])) {
                    $col11= mysqli_real_escape_string($conn,$Row[10]);
                }

                $col12 = "";
                if(isset($Row[11])) {
                    $col12 = mysqli_real_escape_string($conn,$Row[11]);
                }
                $col13 = "";
                if(isset($Row[12])) {
                    $col13 = mysqli_real_escape_string($conn,$Row[12]);
                }
                $col14 = "";
                if(isset($Row[13])) {
                    $col14 = mysqli_real_escape_string($conn,$Row[13]);
                }
                $col15 = "";
                if(isset($Row[14])) {
                    $col15 = mysqli_real_escape_string($conn,$Row[14]);
                }
                $col16 = "";
                if(isset($Row[15])) {
                    $col6 = mysqli_real_escape_string($conn,$Row[15]);
                }
                $col17 = "";
                if(isset($Row[16])) {
                    $col17 = mysqli_real_escape_string($conn,$Row[16]);
                }
                $col18 = "";
                if(isset($Row[17])) {
                    $col18 = mysqli_real_escape_string($conn,$Row[17]);
                }
              
                $col19 = "";
                if(isset($Row[18])) {
                    $col19 = mysqli_real_escape_string($conn,$Row[18]);
                }
                $col20 = "";
                if(isset($Row[19])) {
                    $col20 = mysqli_real_escape_string($conn,$Row[19]);
                }
                $col21 = "";
                if(isset($Row[20])) {
                    $col21 = mysqli_real_escape_string($conn,$Row[20]);
                }
                $col22 = "";
                if(isset($Row[21])) {
                    $col22 = mysqli_real_escape_string($conn,$Row[21]);
                }
                $col23 = "";
                if(isset($Row[22])) {
                    $col23 = mysqli_real_escape_string($conn,$Row[22]);
                }
                $col24 = "";
                if(isset($Row[23])) {
                    $col24 = mysqli_real_escape_string($conn,$Row[23]);
                }
                $col25 = "";
                if(isset($Row[24])) {
                    $col25 = mysqli_real_escape_string($conn,$Row[24]);
                }
                $col26 = "";
                if(isset($Row[25])) {
                    $col26 = mysqli_real_escape_string($conn,$Row[25]);
                }
                $col27 = "";
                if(isset($Row[26])) {
                    $col27 = mysqli_real_escape_string($conn,$Row[26]);
                }
                $col28 = "";
                if(isset($Row[27])) {
                    $col28 = mysqli_real_escape_string($conn,$Row[27]);
                }

                $col29 = "";
                if(isset($Row[28])) {
                    $col29 = mysqli_real_escape_string($conn,$Row[28]);
                }

            
                //$fileName = $_FILES['file']['name'];              
                //if (!empty($date) || !empty($time) || !empty($) || !empty($bname) || !empty($alotted_staff)) {
                    $query = "INSERT INTO `exceldata`(`sr_no`, `date`, `academic_year`, `session`, `alloted_category`, `voucher_type`, `voucher_no`, `roll_no`, `admno_uniqueId`, `status`, `fee_category`, `faculty`, `program`, `department`, `batch`, `receipt_no.`, `fee_head`, `due_amount`, `paid_amount`, `concession_amount`, `scholarship_amount`, `reverse_concession_amount`, `write_off_amount`, `adjusted_amount`, `refund_amount`, `fund_tranCfer_amount`, `remarks`) VALUES ('".$col1."','".$col2."','".$col3."','".$col4."','".$col5."','".$col6."','".$col7."','".$col8."','".$col9."','".$col10."','".$col11."','".$col12."','".$col13."','".$col14."','".$col15."','".$col16."','".$col17."','".$col18."','".$col19."','".$col20."','".$col21."','".$col22."','".$col23."','".$col24."','".$col25."','".$col26."','".$col27."')";
                    $result = mysqli_query($conn, $query);
					//print_r($query);

                    if (! empty($result)) {
                        $type = "success";
                        $message = "Excel Data Imported into the Database";
						header("location:import.php");
                    } else {
                        $type = "error";
                        $message = "Problem in Importing Excel Data";
                        header("location:import.php");
                    }
                //}
             }

         }
  }
  else
  {
        $type = "error";
        $message = "Invalid File Type. Upload Excel File.";
  }
}
?>