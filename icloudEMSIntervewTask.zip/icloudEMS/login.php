
<?php 
include('config.php');
if(isset($_POST['login'])){
    $sql = mysqli_query($conn, "SELECT * FROM `user` WHERE `email`='{$_POST['username']}' AND `password`='{$_POST['password']}'");
    if(mysqli_num_rows($sql) > 0){
        session_start();
        $_SESSION['data']=1;
        //header("Location: import.php");
        echo "<script>
            window.location.href='./import.php';
        </script>";
    
    }else{
        echo "<script>
        alert('Please enter Valid Details');
        window.location.href='./import.php';
        </script>";
    }
}


?>